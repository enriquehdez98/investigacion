var indexSectionsWithContent =
{
  0: "abdefgiklmorsu",
  1: "adeflrs",
  2: "adeflrs",
  3: "abdefgiklmorsu"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions"
};

