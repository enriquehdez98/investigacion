var searchData=
[
  ['rqa_2epy_0',['RQA.py',['../_r_q_a_8py.html',1,'']]]
];
