var searchData=
[
  ['bivariate_5fkernel_5fdensity_0',['bivariate_kernel_density',['../namespace_a_m_i___thomas.html#a54d63488e6e8d56b727448ca641ca88a',1,'AMI_Thomas']]],
  ['bivariate_5fkernel_5fdensity_5fsub_1',['bivariate_kernel_density_sub',['../namespace_a_m_i___thomas.html#a2385be28ca531e0117ae7abe06a44c04',1,'AMI_Thomas']]],
  ['boundary_5fconditions_2',['boundary_conditions',['../namespaceemd.html#aabd4b3057017c7ce7cc48b5fce6745f3',1,'emd']]]
];
