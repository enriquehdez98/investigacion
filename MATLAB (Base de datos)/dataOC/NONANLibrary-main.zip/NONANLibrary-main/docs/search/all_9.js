var searchData=
[
  ['mean_5fand_5famplitude_0',['mean_and_amplitude',['../namespaceemd.html#a4612682c431b7de746821f6c09c93f0a',1,'emd']]]
];
