var searchData=
[
  ['ami_5fstergiou_2epy_0',['AMI_Stergiou.py',['../_a_m_i___stergiou_8py.html',1,'']]],
  ['ami_5fthomas_2epy_1',['AMI_Thomas.py',['../_a_m_i___thomas_8py.html',1,'']]]
];
