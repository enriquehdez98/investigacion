var searchData=
[
  ['univariate_5fkernel_5fdensity_0',['univariate_kernel_density',['../namespace_a_m_i___thomas.html#aaacde7897671063922e107d5afb4c36b',1,'AMI_Thomas']]]
];
