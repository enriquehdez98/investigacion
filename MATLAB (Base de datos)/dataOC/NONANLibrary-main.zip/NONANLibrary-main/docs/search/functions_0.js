var searchData=
[
  ['ami_5fstergiou_0',['AMI_Stergiou',['../namespace_a_m_i___stergiou.html#a98d4510daece6c5bbd73d5e2f38edceb',1,'AMI_Stergiou']]],
  ['ami_5fthomas_1',['AMI_Thomas',['../namespace_a_m_i___thomas.html#a219e5abe0610c569e12598c849372eab',1,'AMI_Thomas']]],
  ['average_5fmutual_5finformation_2',['average_mutual_information',['../namespace_a_m_i___thomas.html#ad966515ea61d2b947457324e02c0fe4d',1,'AMI_Thomas']]]
];
