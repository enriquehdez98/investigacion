var searchData=
[
  ['rqa_0',['RQA',['../namespace_r_q_a.html',1,'']]]
];
