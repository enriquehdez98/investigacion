var _surr___theiler_8py =
[
    [ "surr1", "_surr___theiler_8py.html#aa69ebe34603d579fd2725d1300d9a7cf", null ],
    [ "Surr_Theiler20200723", "_surr___theiler_8py.html#aebac1f5845bb2ed2867dc6bce807883c", null ]
];