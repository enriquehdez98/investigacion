var files_dup =
[
    [ "AMI_Stergiou.py", "_a_m_i___stergiou_8py.html", "_a_m_i___stergiou_8py" ],
    [ "AMI_Thomas.py", "_a_m_i___thomas_8py.html", "_a_m_i___thomas_8py" ],
    [ "Div_JS.py", "_div___j_s_8py.html", "_div___j_s_8py" ],
    [ "Div_KL.py", "_div___k_l_8py.html", "_div___k_l_8py" ],
    [ "emd.py", "emd_8py.html", "emd_8py" ],
    [ "Ent_Ap.py", "_ent___ap_8py.html", "_ent___ap_8py" ],
    [ "Ent_MS_Plus.py", "_ent___m_s___plus_8py.html", "_ent___m_s___plus_8py" ],
    [ "Ent_Permu.py", "_ent___permu_8py.html", "_ent___permu_8py" ],
    [ "Ent_Samp.py", "_ent___samp_8py.html", "_ent___samp_8py" ],
    [ "Ent_Symbolic.py", "_ent___symbolic_8py.html", "_ent___symbolic_8py" ],
    [ "Ent_xSamp.py", "_ent__x_samp_8py.html", "_ent__x_samp_8py" ],
    [ "FNN.py", "_f_n_n_8py.html", "_f_n_n_8py" ],
    [ "LyE_R.py", "_ly_e___r_8py.html", "_ly_e___r_8py" ],
    [ "LyE_W.py", "_ly_e___w_8py.html", "_ly_e___w_8py" ],
    [ "RQA.py", "_r_q_a_8py.html", "_r_q_a_8py" ],
    [ "Surr_findrho.py", "_surr__findrho_8py.html", "_surr__findrho_8py" ],
    [ "Surr_PseudoPeriodic.py", "_surr___pseudo_periodic_8py.html", "_surr___pseudo_periodic_8py" ],
    [ "Surr_Theiler.py", "_surr___theiler_8py.html", "_surr___theiler_8py" ]
];